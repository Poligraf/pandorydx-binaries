#!/bin/sh
# Commander Genius launcher for Pandory DX.
# Searches common USB and SD card mount points automatically.

PACKAGE_REL="pandory/CGenius-package"

# Check locations in this order.
for MOUNT in \
    "/media/usb0" \
    "/media/sdcard" \
    "/mnt/sdcard" \
    "/media/mmcblk1p1"
do
    if [ -d "$MOUNT/$PACKAGE_REL" ]; then
        BUNDLE_DIR="$MOUNT/$PACKAGE_REL"
        break
    fi
done

# Stop if the package was not found.
if [ -z "${BUNDLE_DIR:-}" ]; then
    echo "ERROR: CGenius-package not found." >&2
    echo "Checked:" >&2
    echo "  /media/usb0/$PACKAGE_REL" >&2
    echo "  /media/sdcard/$PACKAGE_REL" >&2
    echo "  /mnt/sdcard/$PACKAGE_REL" >&2
    echo "  /media/mmcblk1p1/$PACKAGE_REL" >&2
    exit 1
fi

LOADER="$BUNDLE_DIR/patchelf/ld-linux-armhf.so.3"
LIB_PATH="$BUNDLE_DIR/libs:$BUNDLE_DIR/patchelf"

# Private HOME for CGenius.
GAME_HOME="$BUNDLE_DIR/home"
mkdir -p "$GAME_HOME"

# Verify required files.
if [ ! -x "$LOADER" ]; then
    echo "ERROR: Bundled loader not found or not executable:" >&2
    echo "$LOADER" >&2
    exit 1
fi

if [ ! -x "$BUNDLE_DIR/CGeniusExe" ]; then
    echo "ERROR: CGeniusExe not found or not executable:" >&2
    echo "$BUNDLE_DIR/CGeniusExe" >&2
    exit 1
fi

# IMPORTANT:
#
# HOME is assigned only to this single child process using env.
# Therefore it does NOT overwrite HOME in the parent launcher
# environment and should not interfere with the RetroArch launcher
# after CGenius exits.
env \
  HOME="$GAME_HOME" \
  SDL_VIDEODRIVER=kmsdrm \
  SDL_KMSDRM_DEVICE_INDEX=0 \
  "$LOADER" \
    --library-path "$LIB_PATH" \
    --preload "/usr/lib/libgbm.so.1:/usr/lib/libdrm.so.2" \
    "$BUNDLE_DIR/CGeniusExe" "$@"

EXIT_CODE=$?

# Cleanup this script's variables.
unset GAME_HOME
unset LIB_PATH
unset LOADER

exit "$EXIT_CODE"