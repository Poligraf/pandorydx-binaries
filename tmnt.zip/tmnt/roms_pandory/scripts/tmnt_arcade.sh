#!/bin/sh
# TMNT launcher for Pandory DX.
#
# - Finds TMNT on USB or SD card.
# - Uses the game directory as HOME.
# - Asks the CPU for full speed (works when this script may write it).
# - Starts TMNT from its game directory, with its frame timing in tmnt.log.

BIN_NAME="TMNT Arcade"
GAME_DIR=""

# Find TMNT on USB or SD card.
for DIR in \
    "/media/usb0/pandory/tmnt" \
    "/media/sdcard/pandory/tmnt" \
    "/mnt/sdcard/pandory/tmnt" \
    "/media/mmcblk1p1/pandory/tmnt"
do
    if [ -x "${DIR}/${BIN_NAME}" ]; then
        GAME_DIR="$DIR"
        break
    fi
done

# Check game exists.
if [ -z "$GAME_DIR" ]; then
    echo "ERROR: Could not find ${BIN_NAME}" >&2
    exit 1
fi

# Start in the game directory.
cd "$GAME_DIR" || exit 1

# CPU governor: performance on every core (silently skipped if not allowed).
for GOV in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance > "$GOV" 2>/dev/null
done

# Log: the governor now in use, then the game's own output and timing.
LOG="${GAME_DIR}/tmnt.log"
echo "governor: $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)" > "$LOG"

# Launch TMNT. TMNT_PROFILE=1 makes it log its frame timing every 2 seconds.
# Optional: TMNT_SCALE=2 for a bigger picture (1 is the default, 0 is the whole screen).
HOME="$GAME_DIR" \
TMNT_SCALE=0  \
TMNT_FRAMESKIP=1 \
    ./"$BIN_NAME" "$@" >> "$LOG" 2>&1

EXIT_CODE=$?

# Cleanup this script's variables.
unset BIN_NAME
unset GAME_DIR
unset DIR
unset GOV
unset LOG

exit "$EXIT_CODE"