Hypseus Singe (v2.12.1)
=======================

https://github.com/DirtBagXon/hypseus-singe

Hypseus is a fork of Matt Ownby's Daphne.

A program to play laserdisc arcade games on a PC or Raspberry Pi.

This version includes Singe support for Fan Made and American Laser Games.

Features:

Updated MPEG2 decoder
Integrated bezel support
Daphne VLDP 32bit upgrade
SDL_GameController configuration
Sinden borders in Singe
Singe Joystick/Lightgun [mouse] support
Singe full 32bit overlay support
Advanced multi joystick configuration
PNG screenshots


Config ini Files
================

These files are now auto-generated, for details on parameters see examples in:

https://github.com/DirtBagXon/hypseus-singe/tree/master/doc


Game arguments and keys
=======================

https://github.com/DirtBagXon/hypseus-singe/blob/master/doc/CmdLine.md


Joystick
========

Includes hypjsch.exe config helper to aide configuration of hypinput.ini


Singe
=====

For Singe LUA games, provide the following arguments to hypseus:

hypseus.exe singe vldp -framefile singe\timegal\timegal.txt -zlua singe\timegal\timegal.zip


Singe joystick [mouse] support
==============================

Singe now automatically interprets joystick d-pad axis change as mouse movement (Gun Games).
Adjust sensitivity via -js_range <1-20> in Singe arguments.

Configure joystick buttons in hypinput.ini

-gamepad -manymouse

Will enable multiple mouse inputs via multiple Game Controller analog axis inputs.

Configure Game Controller in hypinput_gamepad.ini

Software Scoreboard
===================

Enable the original style external scoreboard panel in lair/ace: -scorepanel

Works in conjunction with -fullscreen_window or normal windowed mode.

Support
=======

This software intended for educational purposes only. Please submit issues or pull requests directly to the project.

DO NOT submit issues or request support from the official Daphne forums!

About
=====

Open development of Daphne, by Matt Ownby, ceased several years ago.

Singe LUA games were originally a plugin to Daphne, created by Scott Duensing.

This repository builds upon the Hypseus project initiated by Jeffrey Clark.
It marked the beginning of the transition to SDL2 for Daphne, but excluded Singe.

The name of this application, refers to a sibling of Daphne in Greek mythology.

Modern English pronunciation: “Hip-SEE-us” /ˈhɪp.si.əs/

Thanks go out to Matt Ownby, Scott Duensing, Jeffrey Clark, Manuel Alfayate, David Griffith and the many other developers who made their work available for me to build upon. Without them this project would not be possible.

License
=======

Hypseus Singe, Being Retro Orientated This Humble Emulator Regenerates
Copyright (C) 2021-2026 DirtBagXon

Hypseus, Multiple Arcade Laserdisc Emulator
Copyright (C) 2016 Jeffrey Clark

Daphne, the First Ever Multiple Arcade Laserdisc Emulator
Copyright (C) 1999-2013 Matt Ownby

GNU General Public License version 3

This program is free software: you can redistribute it and/or modify
it under the terms of the [GNU General Public License] as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
[GNU General Public License] for more details.

Trademark
=========

The "Hypseus Singe" mark is used to uniquely identify this project as an Arcade Laserdisc Emulator. Any direct or indirect commercial use of the mark "Hypseus" is strictly prohibited without express permission.
