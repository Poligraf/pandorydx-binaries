Arguments related to bezels
---------------------------

-bezel <lair.png>          [ Specify a png bezel in 'bezels' sub-folder    ]
-bezeldir <path>           [ Specify an absolute path to alternate folder  ]

-scalefactor <25-100>      [ Scale video image [25-100]%                   ]
-shiftx <-100 to 100>      [ Position video window - horizontally          ]
-shifty <-100 to 100>      [ Position video window - vertically            ]
-vertical_screen           [ Reorient calculations for above arguments     ]


Built-in bezels relating to 'lair/ace/tq'
-----------------------------------------

-scorebezel                [ Built-in bezel: ace/lair/tq scoreboard        ]
-scorebezel_alpha <1-2>    [ Built-in bezel: alpha transparency            ]
-scorebezel_scale <1-25>   [ Built-in bezel: scale option                  ]
-scorebezel_position <x y> [ Built-in bezel: position options              ]
-tqkeys                    [ Built-in bezel: tq keyboard displayed         ]

-annunbezel                [ Built-in bezel: ace annunciator               ]
-dedannunbezel             [ Built-in bezel: ace annunciator [Dedicated]   ]
-annunlamps                [ Built-in bezel: staggered: lamps only [conv]  ]

-auxbezel_alpha <1-2>      [ Built-in bezel: alpha transparency            ]
-auxbezel_scale <1-25>     [ Built-in bezel: scale option                  ]
-auxbezel_position <x y>   [ Built-in bezel: position options              ]

-scorepanel                [ Enable software scoreboard in lair/ace/tq     ]
-scorepanel_position <x y> [ Adjust position of software_scorepanel        ]
-scorepanel_scale <1-25>   [ software_scorepanel scale option              ]
-scorescreen <x>           [ Specify an initial scorepanel display screen  ]

[KEY_TILT]                 [ Switch scorepanel display screen lair/ace/tq  ]


Built-in overrides
------------------

- bezels/annunoff.png
- bezels/annunon.png
- bezels/cadet.bmp
- bezels/captain.bmp
- bezels/spaceace.bmp
- bezels/tqkeys.png

- bezels/onspaceace.bmp
- bezels/oncaptain.bmp
- bezels/oncadet.bmp
- bezels/offspaceace.bmp
- bezels/offcaptain.bmp
- bezels/offcadet.bmp


