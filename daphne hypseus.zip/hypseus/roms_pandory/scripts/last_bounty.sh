#!/bin/sh
# Hypseus launcher: lbh (plain /bin/sh, no bashisms).

# ---------------- LOCATE HYPSEUS ----------------
# Use $HYPSEUS_DIR if it is already set and valid, otherwise search the usual mount points.
HYPSEUS_OK=0
if [ -n "$HYPSEUS_DIR" ] && [ -d "$HYPSEUS_DIR" ]; then HYPSEUS_OK=1; fi
if [ "$HYPSEUS_OK" = 0 ]; then
    for DIR in \
        "/media/usb0/pandory/hypseus" \
        "/media/sdcard/pandory/hypseus" \
        "/mnt/sdcard/pandory/hypseus" \
        "/media/mmcblk1p1/pandory/hypseus"; do
        if [ -f "$DIR/hypseus" ] || [ -f "$DIR/Hypseus" ]; then
            HYPSEUS_DIR="$DIR"; HYPSEUS_OK=1; break
        fi
    done
fi
if [ "$HYPSEUS_OK" = 0 ]; then
    echo "$(date): Hypseus folder not found in any known location" >> /tmp/hypseus-early.log
    exit 1
fi

HYPSEUS="$HYPSEUS_DIR/hypseus"
[ -f "$HYPSEUS" ] || { [ -f "$HYPSEUS_DIR/Hypseus" ] && HYPSEUS="$HYPSEUS_DIR/Hypseus"; }
LIBS="$HYPSEUS_DIR/libs"
LOG="$HYPSEUS_DIR/hypseus-launch.log"

# ---------------- GAME ----------------
GAME_ID="lbh"
GAME_NAME="lbh"
SINGE_SCRIPT="$HYPSEUS_DIR/singe/lbh/lbh.singe"
FRAMEFILE="$HYPSEUS_DIR/singe/lbh/lbh.txt"
VIDEO_DIR="$HYPSEUS_DIR/singe/lbh/cdrom"
# --------------------------------------

# Audio buffer in samples (44100 Hz): 2048 = 46 ms, 4096 = 93 ms. Hypseus caps it at 4096.
SOUND_BUFFER="${SOUND_BUFFER:-4096}"

# Files the frontend may use to remember the "last launched game".
# If RetroArch still starts the previous game, find the file (see log) and list it here.
STALE_FILES=""

# ---------------- CLEANUP ----------------
HYP_PID=""
MARK="/tmp/.hypseus-mark.$$"

kill_hypseus() {
    for N in hypseus Hypseus; do
        if command -v killall >/dev/null 2>&1; then
            killall "-$1" "$N" >/dev/null 2>&1
        elif command -v pkill >/dev/null 2>&1; then
            pkill "-$1" -x "$N" >/dev/null 2>&1
        fi
    done
}

cleanup() {
    trap '' EXIT INT TERM HUP
    # Stop our own child if it is still running, then any stray hypseus
    if [ -n "$HYP_PID" ] && kill -0 "$HYP_PID" 2>/dev/null; then
        kill "$HYP_PID" 2>/dev/null
        sleep 1
        kill -9 "$HYP_PID" 2>/dev/null
    fi
    kill_hypseus TERM
    kill_hypseus KILL
    for F in $STALE_FILES; do rm -f "$F"; done
    rm -f "$MARK" /tmp/hypseus-early.log
    sync
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM HUP

# Clear anything left over from a previous run
kill_hypseus TERM
: > "$MARK"

cd "$HYPSEUS_DIR" || { echo "$(date): cd FAILED: $HYPSEUS_DIR" >> /tmp/hypseus-early.log; exit 1; }

# Singe save/config directory (lives under -homedir/ram)
mkdir -p "$HYPSEUS_DIR/ram/singe/$GAME_ID/Cfg"

{
    echo "========================================"
    echo "Hypseus starting: $(date)"
    echo "Hypseus dir: $HYPSEUS_DIR"
    echo "Executable: $HYPSEUS"
    echo "Library directory: $LIBS"
    echo "Working directory: $(pwd)"
    echo "Game: $GAME_NAME"
    echo "SINGE script: $SINGE_SCRIPT"
    echo "Framefile: $FRAMEFILE"
    echo "Video directory: $VIDEO_DIR"
    echo "========================================"
    for F in "$HYPSEUS" "$SINGE_SCRIPT" "$FRAMEFILE" \
             "$HYPSEUS_DIR/hypinput.ini" "$HYPSEUS_DIR/fonts/default.ttf" \
             "$HYPSEUS_DIR/fonts/daphne.ttf" "$HYPSEUS_DIR/pics/annunon.png" \
             "$HYPSEUS_DIR/sound/grumble.wav"; do
        if [ -f "$F" ]; then echo "FOUND:   $F"; else echo "MISSING: $F"; fi
    done
    if [ -d "$VIDEO_DIR" ]; then
        echo "FOUND:   $VIDEO_DIR ($(ls "$VIDEO_DIR" | grep -ci '\.m2v$') .m2v files)"
    else
        echo "MISSING: $VIDEO_DIR"
    fi
    echo "Framefile (first lines):"; head -5 "$FRAMEFILE" 2>/dev/null
    echo "Libraries:"; ls "$LIBS" 2>/dev/null
    echo "Free memory:"; grep -E "MemTotal|MemFree" /proc/meminfo
    echo "========================================"
} >> "$LOG" 2>&1

# Stop if required files are missing
if [ ! -f "$HYPSEUS" ] || [ ! -f "$SINGE_SCRIPT" ] || \
   [ ! -f "$FRAMEFILE" ] || [ ! -d "$VIDEO_DIR" ]; then
    echo "ERROR: required game files are missing. See list above." >> "$LOG"
    exit 1
fi

# -homedir : keeps logs/ ram/ screenshots/ on the storage device
# -keymapfile must be a name RELATIVE to -homedir (an absolute path is never found)
# Run in the background and wait, so signals reach our trap and cleanup always runs.
# stdin is /dev/null so an SDL assertion prompt can never hang the launcher.
LD_LIBRARY_PATH="$LIBS${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
    "$HYPSEUS" singe vldp \
    -homedir "$HYPSEUS_DIR" \
    -datadir "$HYPSEUS_DIR" \
    -script "$SINGE_SCRIPT" \
    -framefile "$FRAMEFILE" \
    -keymapfile hypinput.ini \
    -sound_buffer "$SOUND_BUFFER" \
    -fullscreen \
    -blend_sprites \ 
    -js_range 5 \
    >> "$LOG" 2>&1 < /dev/null &
HYP_PID=$!
wait "$HYP_PID"
EXIT_CODE=$?

{
    echo "========================================"
    echo "Hypseus exited with code: $EXIT_CODE"
    echo "Hypseus ended: $(date)"
    echo "Files changed in /tmp during this run (candidates for a stale 'last game' file):"
    find /tmp -newer "$MARK" 2>/dev/null | grep -v -e hypseus -e "$MARK" | head -20
    echo "========================================"
} >> "$LOG" 2>&1

exit "$EXIT_CODE"
