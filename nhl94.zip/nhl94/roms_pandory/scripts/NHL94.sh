#!/bin/sh
# ninety-four (NHL '94) launcher for Pandory DX.
BIN_NAME="nhl94"
GAME_DIR=""
for DIR in \
    "/media/usb0/pandory/nhl94" \
    "/media/sdcard/pandory/nhl94" \
    "/mnt/sdcard/pandory/nhl94" \
    "/media/mmcblk1p1/pandory/nhl94"
do
    if [ -x "${DIR}/${BIN_NAME}" ]; then GAME_DIR="$DIR"; break; fi
done
if [ -z "$GAME_DIR" ]; then echo "ERROR: Could not find ${BIN_NAME}" >&2; exit 1; fi
cd "$GAME_DIR" || exit 1
for GOV in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance > "$GOV" 2>/dev/null
done
# No log by default. Create an empty file named "debug" in this folder (nhl94/debug) to write nhl94.log,
# with the profile lines, for one run.
if [ -e "${GAME_DIR}/debug" ]; then
    LOG="${GAME_DIR}/nhl94.log"
    export MDRT_PROFILE=1
    echo "governor: $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)" > "$LOG"
else
    LOG="/dev/null"
fi
HLOG="${GAME_DIR}/hacks.log"      # the hack's reading and check: written only when a hack is read
# Your own 1 MB US/Europe cartridge dump goes in rom/ (any file name). Without one the menu asks for it
# (it is remembered in settings.ini). Settings, states, screenshots and GIFs stay in this folder.
ROM_ARG=""
for F in "${GAME_DIR}"/rom/*; do
    if [ -f "$F" ]; then ROM_ARG="$F"; break; fi
done
echo "rom file: ${ROM_ARG:-none}" >> "$LOG"
echo "stack limit: $(ulimit -s), free memory: $(grep -E 'MemAvailable|MemFree' /proc/meminfo 2>/dev/null | head -1)" >> "$LOG"

# ---- hacks ------------------------------------------------------------------------------------------
# A hack ROM in hacks/ plays: its rosters (teams, players, ratings, lines, colours and art; never its code)
# are read from it once into rosters/NAME, and the game's Rosters setting is pointed at them. Take the file
# out of hacks/ and the cartridge's own rosters play again. Needs the cartridge in rom/ as well.
set_setting() {   # KEY VALUE: in settings.ini, replacing the key's line
    if [ -f settings.ini ]; then grep -v "^$1[ =]" settings.ini > settings.ini.tmp; else : > settings.ini.tmp; fi
    echo "$1 = $2" >> settings.ini.tmp
    mv settings.ini.tmp settings.ini
}
get_setting() {   # KEY
    [ -f settings.ini ] && sed -n "s/^$1 *= *//p" settings.ini | head -1
}
HACK=""
for F in "${GAME_DIR}"/hacks/*; do
    [ -f "$F" ] || continue
    case "$F" in
        *.[Zz][Ii][Pp]|*.7[Zz]|*.[Ii][Pp][Ss]|*.[Bb][Pp][Ss]|*.[Tt][Xx][Tt]|*.[Nn][Ff][Oo])
            echo "hacks: skipped ${F##*/} (only raw ROM files: .bin .md .gen)" >> "$LOG"; continue ;;
    esac
    HACK="$F"; break
done
if [ -n "$HACK" ] && [ -z "$ROM_ARG" ]; then
    echo "hacks: ${HACK##*/} found, but a hack needs the cartridge in rom/ too" >> "$LOG"
elif [ -n "$HACK" ]; then
    NAME="${HACK##*/}"; NAME="${NAME%.*}"
    NAME="$(printf '%s' "$NAME" | tr -c 'A-Za-z0-9_.-' '_' | cut -c1-60)"
    [ "$NAME" = "cartridge" ] && NAME="cartridge_hack"
    mkdir -p rosters
    : > "$HLOG.tmp"
    if [ ! -f "rosters/$NAME/teams.csv" ] || [ "$HACK" -nt "rosters/$NAME/teams.csv" ]; then
        echo "hacks: reading the rosters of ${HACK##*/} into rosters/$NAME" >> "$LOG"
        rm -rf "rosters/$NAME"; rm -f "rosters/.$NAME.checked"
        {
            echo "== reading ${HACK##*/} into rosters/$NAME"
            ./"$BIN_NAME" --rom "$ROM_ARG" --extract-rom "$HACK" "rosters/$NAME" 2>&1
            echo "== extract exit code: $?"
        } >> "$HLOG.tmp" 2>&1
    fi
    if [ -f "rosters/$NAME/teams.csv" ] && [ ! -f "rosters/.$NAME.checked" ]; then
        {
            echo "== checking rosters/$NAME (the game's own --check-rosters: what its menu needs of it)"
            ./"$BIN_NAME" --rom "$ROM_ARG" --check-rosters "rosters/$NAME" 2>&1
            echo "== check exit code: $?"
        } >> "$HLOG.tmp" 2>&1
        grep -q "== check exit code: 0" "$HLOG.tmp" && : > "rosters/.$NAME.checked"
    fi
    if [ -s "$HLOG.tmp" ]; then mv "$HLOG.tmp" "$HLOG"; else rm -f "$HLOG.tmp"; fi
    if [ -f "rosters/$NAME/teams.csv" ] && [ -f "rosters/.$NAME.checked" ]; then
        set_setting rules.rosters "$NAME"
        echo "$NAME" > rosters/.launcher_hack
        echo "hacks: playing $NAME" >> "$LOG"
    else
        echo "hacks: ${HACK##*/} could not be used (hacks.log says why); the cartridge's rosters play" >> "$LOG"
    fi
elif [ -f rosters/.launcher_hack ]; then
    # the hack was taken away: back to the cartridge, unless the menu has chosen something else since
    if [ "$(get_setting rules.rosters)" = "$(cat rosters/.launcher_hack)" ]; then set_setting rules.rosters cartridge; fi
    rm -f rosters/.launcher_hack
    echo "hacks: none in hacks/, the cartridge's rosters play" >> "$LOG"
fi

# If the cabinet's joystick is not a known controller, copy its GUID from the log and set:
# export SDL_GAMECONTROLLERCONFIG="<GUID>,<name>,a:b0,b:b1,x:b2,y:b3,start:b9,back:b8,platform:Linux,"
export HOME="$GAME_DIR"
# (set -- keeps a name with spaces and quotes in one piece)
if [ -n "$ROM_ARG" ]; then set -- --rom "$ROM_ARG" "$@"; fi
./"$BIN_NAME" "$@" >> "$LOG" 2>&1
EXIT_CODE=$?
[ "$LOG" != /dev/null ] && echo "nhl94 exit code: $EXIT_CODE (128 + n: killed by signal n; 137 = out of memory)" >> "$LOG"
unset BIN_NAME GAME_DIR DIR GOV LOG HLOG ROM_ARG F HACK NAME
exit "$EXIT_CODE"
