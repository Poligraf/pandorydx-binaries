#!/bin/sh

OPENBOR_DIR="/media/usb0/pandory/openbor/openbor-6391"

OPENBOR="$OPENBOR_DIR/OpenBOR"
LIBS="/media/usb0/pandory/openbor/libs"
LOG="$OPENBOR_DIR/openbor-launch.log"

cd "$OPENBOR_DIR" || exit 1

{
    echo "========================================"
    echo "OpenBOR starting: $(date)"
    echo "Executable: $OPENBOR"
    echo "Library directory: $LIBS"
    echo "Working directory: $(pwd)"
    echo "========================================"
} >> "$LOG"

LD_LIBRARY_PATH="$LIBS${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
    "$OPENBOR" >> "$LOG" 2>&1

EXIT_CODE=$?

{
    echo "========================================"
    echo "OpenBOR exited with code: $EXIT_CODE"
    echo "Exit code: $EXIT_CODE"
    echo "OpenBOR ended: $(date)"
    echo "========================================"
} >> "$LOG"

exit "$EXIT_CODE" 