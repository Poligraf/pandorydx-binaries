local utils = require 'mp.utils'

-- same mount points as the launcher script
local MOUNTS = {
  "/media/usb0",
  "/media/sdcard",
  "/mnt/sdcard",
  "/media/mmcblk1p1",
}
local PAGE = 10

local exts = {}
for e in ("mkv mk3d mka mp4 m4v m4a mov qt avi wmv wma asf flv f4v webm ogv ogm ogg oga opus spx 3gp 3g2 mpg mpeg mpe m2v ts m2ts mts mxf vob divx rm rmvb dv nut y4m mp3 mp2 flac wav aiff aif au aac ac3 eac3 dts ape wv mpc tta caf amr alac dsf m3u m3u8 pls cue"):gmatch("%S+") do
  exts[e] = true
end

local function norm(p)
  p = p:gsub("/+$", "")
  if p == "" then return "/" end
  return p
end

local function exists(p)
  return utils.readdir(p, "dirs") ~= nil
end

-- a mount counts as present only if it exists and is not empty
-- (an unmounted mount point is usually an empty folder)
local function available()
  local list = {}
  for _, m in ipairs(MOUNTS) do
    local all = utils.readdir(m, "all")
    if all and #all > 0 then list[#list + 1] = m end
  end
  return list
end

local function is_mount_root(p)
  p = norm(p)
  for _, m in ipairs(MOUNTS) do
    if p == m then return true end
  end
  return false
end

local function pick_root()
  local env = os.getenv("MEDIA_DIR")
  if env and env ~= "" and exists(env) then return norm(env) end
  local a = available()
  if #a >= 1 then return a[1] end
  return nil
end

-- dir == nil means the Storage screen (list of cards)
local dir, items, sel = pick_root(), {}, 1
local active, names = false, {}
local close

local function by_name(a, b) return a:lower() < b:lower() end

local function parent(p)
  p = norm(p)
  local up = p:match("^(.*)/[^/]*$")
  if not up or up == "" then return "/" end
  return up
end

local function short(s)
  if #s > 36 then return s:sub(1, 33) .. "..." end
  return s
end

local function scan()
  items = {}
  sel = 1
  if dir == nil then
    for _, m in ipairs(available()) do
      items[#items + 1] = {name = m, dir = true, mount = true}
    end
    return
  end
  if dir ~= "/" then items[1] = {name = "..", dir = true} end
  local dirs = utils.readdir(dir, "dirs") or {}
  local files = utils.readdir(dir, "files") or {}
  table.sort(dirs, by_name)
  table.sort(files, by_name)
  for _, d in ipairs(dirs) do
    if d:sub(1, 1) ~= "." then items[#items + 1] = {name = d, dir = true} end
  end
  for _, f in ipairs(files) do
    local ext = f:match("%.([^.]+)$")
    if ext and exts[ext:lower()] then items[#items + 1] = {name = f} end
  end
end

local function draw()
  local out = {dir and short(dir) or "Storage"}
  if #items == 0 then
    out[#out + 1] = dir and "(empty)" or "(no storage found)"
  else
    local first = math.max(1, math.min(sel - math.floor(PAGE / 2), #items - PAGE + 1))
    local last = math.min(#items, first + PAGE - 1)
    for i = first, last do
      local it = items[i]
      out[#out + 1] = (i == sel and "> " or "  ") .. short(it.name) .. (it.dir and "/" or "")
    end
    out[#out + 1] = string.format("%d / %d", sel, #items)
  end
  out[#out + 1] = "e/f:move  a:open  b:up/storage  c:+audio  d:close  1:quit"
  mp.osd_message(table.concat(out, "\n"), 3600)
end

local function step(d)
  if #items == 0 then return end
  sel = (sel - 1 + d) % #items + 1
  draw()
end

local function page(d)
  if #items == 0 then return end
  sel = math.max(1, math.min(#items, sel + d))
  draw()
end

local function go_up()
  if dir == nil then return end
  if is_mount_root(dir) and #available() > 1 then
    dir = nil                      -- top of a card: show the Storage screen
  else
    dir = parent(dir)
  end
  scan(); draw()
end

local function enter()
  local it = items[sel]
  if not it then return end
  if it.mount then
    dir = it.name
    scan(); draw()
  elseif it.name == ".." then
    go_up()
  elseif it.dir then
    dir = utils.join_path(dir, it.name)
    scan(); draw()
  else
    local path = utils.join_path(dir, it.name)
    close()
    mp.commandv("loadfile", path, "replace")
  end
end

local function add_audio()
  local it = items[sel]
  if not it or it.dir or dir == nil then return end
  if mp.get_property_bool("idle-active") then
    mp.osd_message("Start a video first", 2)
    return
  end
  mp.commandv("audio-add", utils.join_path(dir, it.name), "select")
  mp.osd_message("Audio track added", 2)
end

local function bind(key, fn, rep)
  local n = "fb_" .. key
  mp.add_forced_key_binding(key, n, fn, rep and {repeatable = true} or nil)
  names[#names + 1] = n
end

local function open()
  if active then return end
  active = true
  -- the card we were browsing may have been removed
  if dir ~= nil and not exists(dir) then dir = pick_root() end
  -- only one card present: skip the Storage screen
  if dir == nil then
    local a = available()
    if #a == 1 then dir = a[1] end
  end
  scan(); draw()
  bind("UP",    function() step(-1) end, true)
  bind("DOWN",  function() step(1) end, true)
  bind("LEFT",  function() page(-PAGE) end, true)
  bind("RIGHT", function() page(PAGE) end, true)
  bind("e",     function() step(-1) end, true)
  bind("f",     function() step(1) end, true)
  bind("a",     enter)
  bind("ENTER", enter)
  bind("b",     go_up)
  bind("c",     add_audio)
  bind("d",     function() close() end)
  bind("ESC",   function() close() end)
end

function close()
  for _, n in ipairs(names) do mp.remove_key_binding(n) end
  names, active = {}, false
  mp.osd_message("", 0)
end

mp.add_key_binding(nil, "browse", function()
  if active then close() else open() end
end)

mp.observe_property("idle-active", "bool", function(_, idle)
  if idle and not active then open() end
  if not idle and active then close() end
end)