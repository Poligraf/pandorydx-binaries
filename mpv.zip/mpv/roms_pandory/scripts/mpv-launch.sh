#!/bin/sh
# ./mpv-launch.sh              -> file browser (starts in the root of the card it was found on)
# ./mpv-launch.sh file.mkv     -> plays that file; browser appears when it ends
# ./mpv-launch.sh keytest      -> shows the name of every key/button you press (40 s)
#
# Env: VOL=50   MEDIA_DIR=/some/folder

EXIT_CODE=0

# ---- remember the caller's environment so it can be restored at the end ----
OLD_HOME="$HOME"
if [ "${LD_LIBRARY_PATH+set}" = set ]; then
    HAD_LD=1
    OLD_LD="$LD_LIBRARY_PATH"
else
    HAD_LD=0
    OLD_LD=""
fi

# ---- find the mpv folder on whichever card it lives on ----
MPV_DIR=""
MOUNT=""
for M in \
    "/media/usb0" \
    "/media/sdcard" \
    "/mnt/sdcard" \
    "/media/mmcblk1p1"
do
    if [ -f "$M/pandory/mpv/mpv" ]; then
        MOUNT="$M"
        MPV_DIR="$M/pandory/mpv"
        break
    fi
done

if [ -z "$MPV_DIR" ]; then
    EXIT_CODE=1
else
    LIBS="$MPV_DIR/libs"
    CONF="$MPV_DIR/conf"
    FONTS="$CONF/fonts"
    VOL="${VOL:-50}"

    cd "$MPV_DIR" || EXIT_CODE=1
fi

if [ "$EXIT_CODE" -eq 0 ]; then
    chmod +x ./mpv 2>/dev/null

    export LD_LIBRARY_PATH="$LIBS${OLD_LD:+:$OLD_LD}"
    export HOME="$MPV_DIR"
    export MEDIA_DIR="${MEDIA_DIR:-$MOUNT}"
    export SDL_VIDEODRIVER=kmsdrm
    export SDL_RENDER_DRIVER=opengles2
    export SDL_RENDER_SCALE_QUALITY=1

    # ---- fonts: fontconfig points at conf/fonts ----
    cat > /tmp/mpv-fonts.conf <<EOF
<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<fontconfig>
  <dir>$FONTS</dir>
  <cachedir>/tmp/mpv-fontcache</cachedir>
</fontconfig>
EOF
    export FONTCONFIG_FILE=/tmp/mpv-fonts.conf

    if [ "$1" = keytest ]; then
        # ---- key test: key names are drawn on screen only ----
        ./mpv --no-config --input-test --idle=yes --force-window=yes --fs \
              --osd-font="DejaVu Sans" --osd-font-size=34 --vo=sdl \
              --really-quiet >/dev/null 2>&1 &
        PID=$!
        sleep 40
        kill $PID 2>/dev/null
        EXIT_CODE=0
    else
        # ---- normal run ----
        ./mpv --config-dir="$CONF" \
              --vo=sdl --framedrop=vo \
              --hwdec=no --vd-lavc-threads=4 \
              --ao=alsa --audio-device=alsa/hw:0,0 \
              --audio-format=s16 --audio-channels=stereo --audio-samplerate=48000 \
              --audio-buffer=0.2 --volume="$VOL" \
              --really-quiet --no-terminal \
              "$@" >/dev/null 2>&1
        EXIT_CODE=$?
    fi

    rm -f /tmp/mpv-fonts.conf
fi

# ---- restore the caller's environment ----
HOME="$OLD_HOME"
if [ "$HAD_LD" -eq 1 ]; then
    LD_LIBRARY_PATH="$OLD_LD"
    export LD_LIBRARY_PATH
else
    unset LD_LIBRARY_PATH
fi

# ---- cleanup this script's variables ----
unset OLD_HOME
unset OLD_LD
unset HAD_LD
unset M
unset MOUNT
unset MPV_DIR
unset LIBS
unset CONF
unset FONTS
unset VOL
unset PID
unset MEDIA_DIR
unset SDL_VIDEODRIVER
unset SDL_RENDER_DRIVER
unset SDL_RENDER_SCALE_QUALITY
unset FONTCONFIG_FILE

exit "$EXIT_CODE"