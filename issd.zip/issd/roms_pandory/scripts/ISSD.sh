#!/bin/sh
# ISSD Native (International Superstar Soccer Deluxe) launcher for Pandory DX.
#
# - Finds ISSD on USB or SD card.
# - Uses the game directory as HOME (the game's settings and saves go there).
# - Asks the CPU for full speed (works when this script may write it).
# - Starts ISSDNative from its game directory with the ROM beside it; its frame timing goes to issd.log.
# - The ROM is yours: put "International Superstar Soccer Deluxe (USA).sfc" (or any .sfc/.smc of it) in the game directory.
# - Start 1 and Start 2 together open the game's menu (settings, saves, mods), as F1 does on a keyboard.

BIN_NAME="ISSDNative"
GAME_DIR=""

# Find ISSD on USB or SD card.
for DIR in \
    "/media/usb0/pandory/issd" \
    "/media/sdcard/pandory/issd" \
    "/mnt/sdcard/pandory/issd" \
    "/media/mmcblk1p1/pandory/issd"
do
    if [ -x "${DIR}/${BIN_NAME}" ]; then
        GAME_DIR="$DIR"
        break
    fi
done

# Check game exists.
if [ -z "$GAME_DIR" ]; then
    echo "ERROR: Could not find ${BIN_NAME}" >&2
    exit 1
fi

# Start in the game directory.
cd "$GAME_DIR" || exit 1

# The ROM beside the game.
ROM=""
if [ -f "International Superstar Soccer Deluxe (USA).sfc" ]; then
    ROM="International Superstar Soccer Deluxe (USA).sfc"
else
    for F in *.sfc *.smc *.SFC *.SMC; do
        if [ -f "$F" ]; then
            ROM="$F"
            break
        fi
    done
fi

# CPU governor: performance on every core (silently skipped if not allowed).
for GOV in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance > "$GOV" 2>/dev/null
done

# Log: the governor now in use, then the game's own output and, every 120 frames, its timing (ISSD_PROFILE).
LOG="${GAME_DIR}/issd.log"
echo "governor: $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)" > "$LOG"
if [ -z "$ROM" ]; then
    echo "No ROM: put International Superstar Soccer Deluxe (USA).sfc in $GAME_DIR" >> "$LOG"
fi

# The device's buttons, if SDL does not know them as a game controller: issd.log's joystick lines give the GUID; then,
# as SDL_GameControllerDB writes a mapping:
# export SDL_GAMECONTROLLERCONFIG="<GUID>,<name>,a:b0,b:b1,x:b3,y:b2,back:b6,start:b7,dpup:h0.1,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,platform:Linux,"
# ISSD_FRAMESKIP=0 turns off leaving late pictures out; ISSD_LAUNCHER=1 starts with the game's launcher screen.

# Launch ISSD.
if [ -n "$ROM" ] && [ -z "$ISSD_LAUNCHER" ]; then
    HOME="$GAME_DIR" \
    ISSD_PROFILE=1 \
        ./"$BIN_NAME" --no-launcher --rom "$ROM" "$@" >> "$LOG" 2>&1
else
    HOME="$GAME_DIR" \
    ISSD_PROFILE=1 \
        ./"$BIN_NAME" "$@" >> "$LOG" 2>&1
fi

EXIT_CODE=$?

# Cleanup this script's variables.
unset BIN_NAME
unset GAME_DIR
unset DIR
unset ROM
unset F
unset GOV
unset LOG

exit "$EXIT_CODE"
