#!/bin/sh

PACKAGE_REL="pandory/openclaw"

# Check locations in this order.
for MOUNT in \
    "/media/usb0" \
    "/media/sdcard" \
    "/mnt/sdcard" \
    "/media/mmcblk1p1"
do
    if [ -d "$MOUNT/$PACKAGE_REL" ]; then
        OPENCLAW_DIR="$MOUNT/$PACKAGE_REL"
        break
    fi
done

# Stop if the package was not found on any known mount point.
if [ -z "${OPENCLAW_DIR:-}" ]; then
    echo "ERROR: openclaw package not found." >&2
    echo "Checked:" >&2
    echo "  /media/usb0/$PACKAGE_REL" >&2
    echo "  /media/sdcard/$PACKAGE_REL" >&2
    echo "  /mnt/sdcard/$PACKAGE_REL" >&2
    echo "  /media/mmcblk1p1/$PACKAGE_REL" >&2
    exit 1
fi

OPENCLAW="$OPENCLAW_DIR/openclaw"
LIBS="$OPENCLAW_DIR/libs"

cd "$OPENCLAW_DIR" || exit 1

export HOME="$OPENCLAW_DIR"

# ============================================================
# SDL / KMSDRM
# ============================================================
export SDL_VIDEODRIVER="kmsdrm"
export SDL_KMSDRM_DEVICE_INDEX="0"
export SDL_RENDER_DRIVER="opengles2"

# Request 640x480 from SDL
export SDL_VIDEO_FULLSCREEN_DISPLAY="640x480"

# Bundled libraries
export LD_LIBRARY_PATH="$LIBS${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

# ============================================================
# Verify OpenClaw binary
# ============================================================
if [ ! -x "$OPENCLAW" ]; then
    echo "ERROR: OpenClaw executable not found: $OPENCLAW" >&2
    exit 1
fi

# ============================================================
# Verify font
# ============================================================
if [ ! -f "$OPENCLAW_DIR/clacon.ttf" ]; then
    echo "ERROR: clacon.ttf not found: $OPENCLAW_DIR/clacon.ttf" >&2
    exit 1
fi

# ============================================================
# Start OpenClaw
# ============================================================
"$OPENCLAW"
EXIT_CODE=$?

# Cleanup this script's variables.
unset PACKAGE_REL
unset MOUNT
unset OPENCLAW_DIR
unset OPENCLAW
unset LIBS

exit "$EXIT_CODE"