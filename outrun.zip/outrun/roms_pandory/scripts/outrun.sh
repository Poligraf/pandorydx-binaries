
#!/bin/sh
# CannonBall (OutRun) launcher for Pandory DX.
BIN_NAME="cannonball"
GAME_DIR=""

for DIR in \
    "/media/usb0/pandory/cannonball" \
    "/media/sdcard/pandory/cannonball" \
    "/mnt/sdcard/pandory/cannonball" \
    "/media/mmcblk1p1/pandory/cannonball"
do
    if [ -x "${DIR}/${BIN_NAME}" ]; then
        GAME_DIR="$DIR"
        break
    fi
done

if [ -z "$GAME_DIR" ]; then
    echo "ERROR: Could not find ${BIN_NAME}" >&2
    exit 1
fi

cd "$GAME_DIR" || exit 1

for GOV in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance > "$GOV" 2>/dev/null
done

export HOME="$GAME_DIR"

"./$BIN_NAME" "$@"
EXIT_CODE=$?

unset BIN_NAME GAME_DIR DIR GOV EXIT_CODE

exit 0
