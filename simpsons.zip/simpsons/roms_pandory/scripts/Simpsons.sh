#!/bin/sh
# The Simpsons Mr. Plow Edition launcher for Pandory DX.
#
# - Finds Simpsons on USB or SD card.
# - Uses the game directory as HOME.
# - Asks the CPU for full speed (works when this script may write it).
# - Starts Simpsons from its game directory; its frame timing goes to simpsons.log.
# - The first start takes the game's assets out of simpsons.zip (MAME's The Simpsons, 4 Players World set 1) beside
#   the game: put simpsons.zip in the game directory before it.

BIN_NAME="Simpsons"
GAME_DIR=""

# Find Simpsons on USB or SD card.
for DIR in \
    "/media/usb0/pandory/simpsons" \
    "/media/sdcard/pandory/simpsons" \
    "/mnt/sdcard/pandory/simpsons" \
    "/media/mmcblk1p1/pandory/simpsons"
do
    if [ -x "${DIR}/${BIN_NAME}" ]; then
        GAME_DIR="$DIR"
        break
    fi
done

# Check game exists.
if [ -z "$GAME_DIR" ]; then
    echo "ERROR: Could not find ${BIN_NAME}" >&2
    exit 1
fi

# Start in the game directory.
cd "$GAME_DIR" || exit 1

# CPU governor: performance on every core (silently skipped if not allowed).
for GOV in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance > "$GOV" 2>/dev/null
done

# Log: the governor now in use, then the game's own output and, every 120 frames, its timing (SIMPSONS_PROFILE).
LOG="${GAME_DIR}/simpsons.log"
echo "governor: $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)" > "$LOG"

# The device's buttons, if SDL does not know them as a game controller: simpsons.log's "Joystick ..." lines give the
# GUID; then, as SDL_GameControllerDB writes a mapping:
# export SDL_GAMECONTROLLERCONFIG="<GUID>,<name>,a:b0,b:b1,x:b3,y:b2,back:b6,start:b7,dpup:h0.1,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,platform:Linux,"

# Launch Simpsons.
HOME="$GAME_DIR" \
SIMPSONS_PROFILE=1 \
    ./"$BIN_NAME" "$@" >> "$LOG" 2>&1

EXIT_CODE=$?

# Cleanup this script's variables.
unset BIN_NAME
unset GAME_DIR
unset DIR
unset GOV
unset LOG

exit "$EXIT_CODE"
